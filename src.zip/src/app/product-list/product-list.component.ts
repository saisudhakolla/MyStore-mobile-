import { Component, OnInit } from '@angular/core';
import { faFacebookF, faTwitterSquare, faInstagram } from '@fortawesome/free-brands-svg-icons';
import { products } from '../products';
import { CartService } from '../cart.service';
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  faFacebookF = faFacebookF;
  faTwitterSquare = faTwitterSquare;
  faInstagram = faInstagram;

  products = products;
  items;
  product;

  constructor(private cart: CartService) { }

  share(){
    window.alert('This product has been shared');
  }

  

  addToCart(product) {
    window.alert('Your product has been added to the cart!');
    this.cart.addToCart(product);
  }
  ngOnInit() {
  }

}
