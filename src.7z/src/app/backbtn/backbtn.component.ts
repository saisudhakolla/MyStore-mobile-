import { Component, OnInit } from '@angular/core';
import { faLongArrowAltLeft } from '@fortawesome/free-solid-svg-icons';
import { Location } from '@angular/common';

@Component({
  selector: 'app-backbtn',
  templateUrl: './backbtn.component.html',
  styleUrls: ['./backbtn.component.css']
})
export class BackbtnComponent implements OnInit {
  faLongArrowAltLeft = faLongArrowAltLeft;

  constructor(private location: Location) { }

  backClick(){
    this.location.back();
  }

  ngOnInit() {
  }

}
