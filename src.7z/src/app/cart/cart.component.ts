import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm } from '@angular/forms';
import { CartService } from '../cart.service';

export class Model{
        name: string;
        address: string;
}

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  items;
  checkoutform;
  
  model: Model={
    name:'',
    address:''
}

  constructor( private cart: CartService, private fb: FormBuilder) {

    this.items = this.cart.getItems();
   }
  
   onSubmit(checkout: NgForm){
      window.alert('Your order has been submitted');
      this.items= this.cart.clearCart();
      checkout.reset();
      //this.checkoutform.reset();
   }

  ngOnInit() {
  }

}
